Pentru ca proiectul sa mearga trebuie specificate in clasa Main pathruile pentru:
-folderul unde se afla fisierele de input sub forma :"F:\\ex\\folderCuFisiere\\" in variabila "directoryPath"
-foldrul unde se va crea fisierul de output sub forma:"F:\\ex\\ex2\\comenzi.txt" in variabila "outputPath"



In fisierul de dependencies am o librarie pentru rulat de teste.
